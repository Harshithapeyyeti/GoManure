package com.pierfrancescosoffritti.androidyoutubeplayer;

public final class BuildConfig {
    @Deprecated
    public static final String APPLICATION_ID = "com.pierfrancescosoffritti.androidyoutubeplayer";
    public static final String BUILD_TYPE = "release";
    public static final boolean DEBUG = false;
    public static final String FLAVOR = "";
    public static final String LIBRARY_PACKAGE_NAME = "com.pierfrancescosoffritti.androidyoutubeplayer";
    public static final int VERSION_CODE = 15;
    public static final String VERSION_NAME = "10.0.5";
}
