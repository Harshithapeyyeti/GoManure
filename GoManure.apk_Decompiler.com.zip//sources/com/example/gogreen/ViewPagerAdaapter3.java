package com.example.gogreen;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.viewpager.widget.PagerAdapter;

public class ViewPagerAdaapter3 extends PagerAdapter {
    Context context;
    int[] descriptions1 = {R.string.ans1, R.string.ans2, R.string.ans3, R.string.ans4, R.string.ans5, R.string.ans6};
    int[] headings1 = {R.string.q1, R.string.q2, R.string.q3, R.string.q4, R.string.q5, R.string.q6};

    public ViewPagerAdaapter3(Context context2) {
        this.context = context2;
    }

    public int getCount() {
        return this.headings1.length;
    }

    /* JADX WARNING: type inference failed for: r3v0, types: [java.lang.Object] */
    /* JADX WARNING: Unknown variable types count: 1 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean isViewFromObject(@androidx.annotation.NonNull android.view.View r2, @androidx.annotation.NonNull java.lang.Object r3) {
        /*
            r1 = this;
            r0 = r3
            android.widget.LinearLayout r0 = (android.widget.LinearLayout) r0
            if (r2 != r0) goto L_0x0007
            r0 = 1
            goto L_0x0008
        L_0x0007:
            r0 = 0
        L_0x0008:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.example.gogreen.ViewPagerAdaapter3.isViewFromObject(android.view.View, java.lang.Object):boolean");
    }

    @NonNull
    public Object instantiateItem(@NonNull ViewGroup container, int position) {
        View view = ((LayoutInflater) this.context.getSystemService("layout_inflater")).inflate(R.layout.slider_layoutbb, container, false);
        ((TextView) view.findViewById(R.id.textques)).setText(this.headings1[position]);
        ((TextView) view.findViewById(R.id.textans)).setText(this.descriptions1[position]);
        container.addView(view);
        return view;
    }

    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
        container.removeView((LinearLayout) object);
    }
}
