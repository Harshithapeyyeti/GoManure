package com.example.gogreen;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class Storemenu extends AppCompatActivity {
    Button bang;
    Button hyder;

    /* access modifiers changed from: protected */
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((int) R.layout.activity_storemenu);
        this.bang = (Button) findViewById(R.id.banglore);
        this.hyder = (Button) findViewById(R.id.hyd2);
        this.hyder.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Storemenu.this.startActivity(new Intent(Storemenu.this, Checkstore1.class));
            }
        });
        this.bang.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Storemenu.this.startActivity(new Intent(Storemenu.this, Checckstore2.class));
            }
        });
    }
}
