package com.example.gogreen;

import android.os.Bundle;
import android.transition.AutoTransition;
import android.transition.TransitionManager;
import android.view.View;
import android.widget.LinearLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.views.YouTubePlayerView;

public class Homecomposting extends AppCompatActivity {
    LinearLayout layo;
    LinearLayout layo2;
    ViewPager mSlideViewPager;
    ViewPagerAdaapter3 viewPagerAdaapter;
    ViewPager.OnPageChangeListener viewlistener = new ViewPager.OnPageChangeListener() {
        public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
        }

        public void onPageSelected(int position) {
        }

        public void onPageScrollStateChanged(int state) {
        }
    };
    ViewPager vp1;
    YouTubePlayerView y4;
    YouTubePlayerView y5;
    YouTubePlayerView youTubePlayerView1;
    YouTubePlayerView youTubePlayerView33;

    /* access modifiers changed from: protected */
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((int) R.layout.activity_homecomposting);
        this.youTubePlayerView1 = (YouTubePlayerView) findViewById(R.id.youtube_player_view2);
        getLifecycle().addObserver(this.youTubePlayerView1);
        this.youTubePlayerView33 = (YouTubePlayerView) findViewById(R.id.youtube_player_view3);
        getLifecycle().addObserver(this.youTubePlayerView33);
        this.y4 = (YouTubePlayerView) findViewById(R.id.youtube_player_view4);
        getLifecycle().addObserver(this.y4);
        this.y5 = (YouTubePlayerView) findViewById(R.id.youtube_player_view5);
        getLifecycle().addObserver(this.y5);
        this.layo = (LinearLayout) findViewById(R.id.layyyyyy);
        this.layo.getLayoutTransition().enableTransitionType(4);
        this.layo2 = (LinearLayout) findViewById(R.id.layyyyyy2);
        this.layo2.getLayoutTransition().enableTransitionType(4);
        this.mSlideViewPager = (ViewPager) findViewById(R.id.slideviewPager2);
        this.viewPagerAdaapter = new ViewPagerAdaapter3(this);
        this.mSlideViewPager.setAdapter(this.viewPagerAdaapter);
        this.mSlideViewPager.addOnPageChangeListener(this.viewlistener);
    }

    public void cliiii(View view) {
        int v4 = 0;
        int v = this.youTubePlayerView33.getVisibility() == 8 ? 0 : 8;
        TransitionManager.beginDelayedTransition(this.layo, new AutoTransition());
        this.youTubePlayerView33.setVisibility(v);
        int v2 = this.youTubePlayerView1.getVisibility() == 8 ? 0 : 8;
        TransitionManager.beginDelayedTransition(this.layo, new AutoTransition());
        this.youTubePlayerView1.setVisibility(v2);
        int v3 = this.y4.getVisibility() == 8 ? 0 : 8;
        TransitionManager.beginDelayedTransition(this.layo, new AutoTransition());
        this.y4.setVisibility(v3);
        if (this.y5.getVisibility() != 8) {
            v4 = 8;
        }
        TransitionManager.beginDelayedTransition(this.layo, new AutoTransition());
        this.y5.setVisibility(v4);
    }

    public void cliiii2(View view) {
        int vpage1 = 8;
        if (this.mSlideViewPager.getVisibility() == 8) {
            vpage1 = 0;
        }
        TransitionManager.beginDelayedTransition(this.layo2, new AutoTransition());
        this.mSlideViewPager.setVisibility(vpage1);
    }

    private int getitem(int i) {
        return this.mSlideViewPager.getCurrentItem() + i;
    }
}
