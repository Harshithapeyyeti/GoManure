package com.example.gogreen;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.viewpager.widget.PagerAdapter;

public class ViewPagerAdaapter extends PagerAdapter {
    Context context;
    int[] descriptions = {R.string.subname1, R.string.subname3, R.string.subname2};
    int[] headings = {R.string.app_name, R.string.app_name, R.string.app_name};
    int[] images = {R.drawable.savesoil, R.drawable.soilmanure, R.drawable.theme};

    public ViewPagerAdaapter(Context context2) {
        this.context = context2;
    }

    public int getCount() {
        return this.headings.length;
    }

    /* JADX WARNING: type inference failed for: r3v0, types: [java.lang.Object] */
    /* JADX WARNING: Unknown variable types count: 1 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean isViewFromObject(@androidx.annotation.NonNull android.view.View r2, @androidx.annotation.NonNull java.lang.Object r3) {
        /*
            r1 = this;
            r0 = r3
            android.widget.LinearLayout r0 = (android.widget.LinearLayout) r0
            if (r2 != r0) goto L_0x0007
            r0 = 1
            goto L_0x0008
        L_0x0007:
            r0 = 0
        L_0x0008:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.example.gogreen.ViewPagerAdaapter.isViewFromObject(android.view.View, java.lang.Object):boolean");
    }

    @NonNull
    public Object instantiateItem(@NonNull ViewGroup container, int position) {
        View view = ((LayoutInflater) this.context.getSystemService("layout_inflater")).inflate(R.layout.slider_layout, container, false);
        ((ImageView) view.findViewById(R.id.titleImage)).setImageResource(this.images[position]);
        ((TextView) view.findViewById(R.id.texttitle)).setText(this.headings[position]);
        ((TextView) view.findViewById(R.id.textdescription)).setText(this.descriptions[position]);
        container.addView(view);
        return view;
    }

    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
        container.removeView((LinearLayout) object);
    }
}
