package com.example.gogreen;

import android.os.Bundle;
import android.transition.AutoTransition;
import android.transition.TransitionManager;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.views.YouTubePlayerView;

public class GreenManureben extends AppCompatActivity {
    TextView detailstext;
    TextView detailstext2;
    TextView detailstext3;
    TextView detailstext4;
    LinearLayout layouta;
    LinearLayout layoutb;
    LinearLayout layoutc;
    LinearLayout layoutd;

    /* access modifiers changed from: protected */
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((int) R.layout.activity_green_manureben);
        getLifecycle().addObserver((YouTubePlayerView) findViewById(R.id.youtube_player_view));
        this.detailstext = (TextView) findViewById(R.id.detail);
        this.layouta = (LinearLayout) findViewById(R.id.layout2);
        this.layouta.getLayoutTransition().enableTransitionType(4);
        this.detailstext2 = (TextView) findViewById(R.id.detail2);
        this.layoutb = (LinearLayout) findViewById(R.id.layout4);
        this.layoutb.getLayoutTransition().enableTransitionType(4);
        this.detailstext3 = (TextView) findViewById(R.id.detail3);
        this.layoutc = (LinearLayout) findViewById(R.id.layout5);
        this.layoutc.getLayoutTransition().enableTransitionType(4);
        this.detailstext4 = (TextView) findViewById(R.id.detail4);
        this.layoutd = (LinearLayout) findViewById(R.id.layout6);
        this.layoutd.getLayoutTransition().enableTransitionType(4);
    }

    public void expand(View view) {
        int v = 8;
        if (this.detailstext.getVisibility() == 8) {
            v = 0;
        }
        TransitionManager.beginDelayedTransition(this.layouta, new AutoTransition());
        this.detailstext.setVisibility(v);
    }

    public void expand2(View view) {
        int v = 8;
        if (this.detailstext2.getVisibility() == 8) {
            v = 0;
        }
        TransitionManager.beginDelayedTransition(this.layoutb, new AutoTransition());
        this.detailstext2.setVisibility(v);
    }

    public void expand5(View view) {
        int v = 8;
        if (this.detailstext3.getVisibility() == 8) {
            v = 0;
        }
        TransitionManager.beginDelayedTransition(this.layoutc, new AutoTransition());
        this.detailstext3.setVisibility(v);
    }

    public void expand6(View view) {
        int v = 8;
        if (this.detailstext4.getVisibility() == 8) {
            v = 0;
        }
        TransitionManager.beginDelayedTransition(this.layoutd, new AutoTransition());
        this.detailstext4.setVisibility(v);
    }
}
