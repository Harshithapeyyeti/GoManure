package com.example.gogreen;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import androidx.appcompat.app.AppCompatActivity;

public class Checkstore1 extends AppCompatActivity {
    ImageButton dial1;
    ImageButton dial2;
    ImageButton dial3;
    ImageButton loct1;
    ImageButton loct2;
    ImageButton loct3;

    /* access modifiers changed from: protected */
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((int) R.layout.activity_checkstore1);
        this.loct1 = (ImageButton) findViewById(R.id.loc1);
        this.loct1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Checkstore1.this.showloct1();
            }
        });
        this.dial1 = (ImageButton) findViewById(R.id.phone1);
        this.dial1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Checkstore1.this.showdial1();
            }
        });
        this.loct1 = (ImageButton) findViewById(R.id.loc2);
        this.loct1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Checkstore1.this.showloct2();
            }
        });
        this.dial1 = (ImageButton) findViewById(R.id.phone2);
        this.dial1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Checkstore1.this.showdial2();
            }
        });
        this.loct1 = (ImageButton) findViewById(R.id.loc3);
        this.loct1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Checkstore1.this.showloct3();
            }
        });
        this.dial1 = (ImageButton) findViewById(R.id.phone3);
        this.dial1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Checkstore1.this.showdial3();
            }
        });
    }

    /* access modifiers changed from: private */
    public void showloct1() {
        Intent intent = new Intent("android.intent.action.VIEW");
        intent.setData(Uri.parse("https://www.google.com/maps/dir//nisha+nurseries/@17.5242083,78.3751648,11z/data=!4m8!4m7!1m0!1m5!1m1!1s0x3bcb8be03ab6dd29:0x5038bcb7dfb8844a!2m2!1d78.383481!2d17.629584"));
        startActivity(intent);
    }

    /* access modifiers changed from: private */
    public void showdial1() {
        startActivity(new Intent("android.intent.action.VIEW", Uri.parse("tel:09949496361")));
    }

    /* access modifiers changed from: private */
    public void showloct2() {
        Intent intent = new Intent("android.intent.action.VIEW");
        intent.setData(Uri.parse("https://www.google.com/maps/dir//neo+seeds/@17.425179,78.4564467,12z/data=!4m8!4m7!1m0!1m5!1m1!1s0x3bcb99dee6f4ed99:0x22a881bbad1e2553!2m2!1d78.479277!2d17.3998725"));
        startActivity(intent);
    }

    /* access modifiers changed from: private */
    public void showdial2() {
        startActivity(new Intent("android.intent.action.VIEW", Uri.parse("tel:07947190176")));
    }

    /* access modifiers changed from: private */
    public void showloct3() {
        Intent intent = new Intent("android.intent.action.VIEW");
        intent.setData(Uri.parse("https://www.google.com/maps/dir//Prakruthi+agro+agency/@17.46851,78.5550408,14z/data=!4m8!4m7!1m0!1m5!1m1!1s0x3bcb9dbeb99d8d09:0x710949fabaa8ab2b!2m2!1d78.5736865!2d17.4920451"));
        startActivity(intent);
    }

    /* access modifiers changed from: private */
    public void showdial3() {
        startActivity(new Intent("android.intent.action.VIEW", Uri.parse("tel:07947477728")));
    }
}
