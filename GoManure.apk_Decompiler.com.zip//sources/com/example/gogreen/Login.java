package com.example.gogreen;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class Login extends AppCompatActivity {
    public Button Login;
    public EditText email1;
    /* access modifiers changed from: private */
    public FirebaseAuth firebaseAuth1;
    public EditText password1;
    /* access modifiers changed from: private */
    public ProgressDialog progressDialog1;
    public Button reg;

    /* access modifiers changed from: protected */
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((int) R.layout.activity_login);
        this.email1 = (EditText) findViewById(R.id.email1);
        this.password1 = (EditText) findViewById(R.id.ed2);
        this.Login = (Button) findViewById(R.id.Login);
        this.firebaseAuth1 = FirebaseAuth.getInstance();
        this.progressDialog1 = new ProgressDialog(this);
        this.reg = (Button) findViewById(R.id.button2);
        this.reg.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Login.this.startActivity(new Intent(Login.this, Registration.class));
            }
        });
        this.Login.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Login.this.userLogin();
            }
        });
    }

    public void userLogin() {
        String em1 = this.email1.getText().toString().trim();
        String pw1 = this.password1.getText().toString().trim();
        if (TextUtils.isEmpty(em1)) {
            Toast.makeText(this, "Enter email id", 1).show();
        } else if (TextUtils.isEmpty(pw1)) {
            Toast.makeText(this, "Enter password", 1).show();
        } else {
            this.progressDialog1.setMessage("Logging User");
            this.progressDialog1.show();
            this.firebaseAuth1.signInWithEmailAndPassword(em1, pw1).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if (!task.isSuccessful()) {
                        Toast.makeText(Login.this, "Login unsuccessful", 1).show();
                        Login.this.progressDialog1.dismiss();
                    } else if (Login.this.firebaseAuth1.getCurrentUser().isEmailVerified()) {
                        Toast.makeText(Login.this, "Login successful", 1).show();
                        Login.this.startActivity(new Intent(Login.this, Menu.class));
                        Login.this.progressDialog1.dismiss();
                    } else {
                        Toast.makeText(Login.this, "Please verify your email", 1).show();
                        Login.this.progressDialog1.dismiss();
                    }
                }
            });
        }
    }
}
