package com.example.gogreen;

import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

public class MainActivity extends AppCompatActivity {
    TextView back;
    TextView[] dots;
    LinearLayout mDottLayout;
    ViewPager mSlideViewPager;
    TextView next;
    TextView skip;
    ViewPagerAdaapter viewPagerAdaapter;
    ViewPager.OnPageChangeListener viewlistener = new ViewPager.OnPageChangeListener() {
        public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
        }

        public void onPageSelected(int position) {
            MainActivity.this.setupindicator(position);
            if (position > 0) {
                MainActivity.this.back.setVisibility(0);
            } else {
                MainActivity.this.back.setVisibility(4);
            }
        }

        public void onPageScrollStateChanged(int state) {
        }
    };

    /* access modifiers changed from: protected */
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((int) R.layout.activity_main);
        this.back = (TextView) findViewById(R.id.button2);
        this.skip = (TextView) findViewById(R.id.button);
        this.next = (TextView) findViewById(R.id.button3);
        this.back.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (MainActivity.this.getitem(0) > 0) {
                    MainActivity.this.mSlideViewPager.setCurrentItem(MainActivity.this.getitem(-1), true);
                }
            }
        });
        this.skip.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                MainActivity.this.startActivity(new Intent(MainActivity.this, Login.class));
                MainActivity.this.finish();
            }
        });
        this.next.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (MainActivity.this.getitem(0) < 2) {
                    MainActivity.this.mSlideViewPager.setCurrentItem(MainActivity.this.getitem(1), true);
                    return;
                }
                MainActivity.this.startActivity(new Intent(MainActivity.this, Login.class));
                MainActivity.this.finish();
            }
        });
        this.mSlideViewPager = (ViewPager) findViewById(R.id.slideviewPager);
        this.mDottLayout = (LinearLayout) findViewById(R.id.indicator);
        this.viewPagerAdaapter = new ViewPagerAdaapter(this);
        this.mSlideViewPager.setAdapter(this.viewPagerAdaapter);
        setupindicator(0);
        this.mSlideViewPager.addOnPageChangeListener(this.viewlistener);
    }

    public void setupindicator(int position) {
        this.dots = new TextView[3];
        this.mDottLayout.removeAllViews();
        int i = 0;
        while (true) {
            TextView[] textViewArr = this.dots;
            if (i < textViewArr.length) {
                textViewArr[i] = new TextView(this);
                this.dots[i].setText(Html.fromHtml("&#8226"));
                this.dots[i].setTextSize(35.0f);
                this.dots[i].setTextColor(getResources().getColor(R.color.colorAccent));
                this.mDottLayout.addView(this.dots[i]);
                i++;
            } else {
                textViewArr[position].setTextColor(getResources().getColor(R.color.colorPrimary));
                return;
            }
        }
    }

    /* access modifiers changed from: private */
    public int getitem(int i) {
        return this.mSlideViewPager.getCurrentItem() + i;
    }
}
