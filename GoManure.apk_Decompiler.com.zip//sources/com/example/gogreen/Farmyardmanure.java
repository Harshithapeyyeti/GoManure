package com.example.gogreen;

import android.os.Bundle;
import android.transition.AutoTransition;
import android.transition.TransitionManager;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.views.YouTubePlayerView;

public class Farmyardmanure extends AppCompatActivity {
    TextView detailt;
    TextView detailt2;
    TextView detailt3;
    TextView detailt4;
    TextView detailt5;
    LinearLayout layouta2;
    LinearLayout layoutb2;
    LinearLayout layoutc2;
    LinearLayout layoutd2;
    LinearLayout layoute2;

    /* access modifiers changed from: protected */
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((int) R.layout.activity_farmyardmanure);
        getLifecycle().addObserver((YouTubePlayerView) findViewById(R.id.youtube_player_view));
        this.detailt = (TextView) findViewById(R.id.det1);
        this.layouta2 = (LinearLayout) findViewById(R.id.lay2);
        this.layouta2.getLayoutTransition().enableTransitionType(4);
        this.detailt2 = (TextView) findViewById(R.id.det2);
        this.layoutb2 = (LinearLayout) findViewById(R.id.lay4);
        this.layoutb2.getLayoutTransition().enableTransitionType(4);
        this.detailt3 = (TextView) findViewById(R.id.det3);
        this.layoutc2 = (LinearLayout) findViewById(R.id.lay5);
        this.layoutc2.getLayoutTransition().enableTransitionType(4);
        this.detailt4 = (TextView) findViewById(R.id.det4);
        this.layoutd2 = (LinearLayout) findViewById(R.id.lay6);
        this.layoutd2.getLayoutTransition().enableTransitionType(4);
        this.detailt5 = (TextView) findViewById(R.id.det5);
        this.layoute2 = (LinearLayout) findViewById(R.id.lay7);
        this.layoute2.getLayoutTransition().enableTransitionType(4);
    }

    public void exp(View view) {
        int v = 8;
        if (this.detailt.getVisibility() == 8) {
            v = 0;
        }
        TransitionManager.beginDelayedTransition(this.layouta2, new AutoTransition());
        this.detailt.setVisibility(v);
    }

    public void exp2(View view) {
        int v = 8;
        if (this.detailt2.getVisibility() == 8) {
            v = 0;
        }
        TransitionManager.beginDelayedTransition(this.layoutb2, new AutoTransition());
        this.detailt2.setVisibility(v);
    }

    public void exp5(View view) {
        int v = 8;
        if (this.detailt3.getVisibility() == 8) {
            v = 0;
        }
        TransitionManager.beginDelayedTransition(this.layoutc2, new AutoTransition());
        this.detailt3.setVisibility(v);
    }

    public void exp6(View view) {
        int v = 8;
        if (this.detailt4.getVisibility() == 8) {
            v = 0;
        }
        TransitionManager.beginDelayedTransition(this.layoutd2, new AutoTransition());
        this.detailt4.setVisibility(v);
    }

    public void exp7(View view) {
        int v = 8;
        if (this.detailt5.getVisibility() == 8) {
            v = 0;
        }
        TransitionManager.beginDelayedTransition(this.layoute2, new AutoTransition());
        this.detailt5.setVisibility(v);
    }
}
