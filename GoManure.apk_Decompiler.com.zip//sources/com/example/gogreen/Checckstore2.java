package com.example.gogreen;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import androidx.appcompat.app.AppCompatActivity;

public class Checckstore2 extends AppCompatActivity {
    ImageButton bdial1;
    ImageButton bdial2;
    ImageButton bdial3;
    ImageButton bloct1;
    ImageButton bloct2;
    ImageButton bloct3;

    /* access modifiers changed from: protected */
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((int) R.layout.activity_checckstore2);
        this.bloct1 = (ImageButton) findViewById(R.id.bloc1);
        this.bloct1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Checckstore2.this.showloct1();
            }
        });
        this.bdial1 = (ImageButton) findViewById(R.id.bphone1);
        this.bdial1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Checckstore2.this.showdial1();
            }
        });
        this.bloct1 = (ImageButton) findViewById(R.id.bloc2);
        this.bloct1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Checckstore2.this.showloct2();
            }
        });
        this.bdial1 = (ImageButton) findViewById(R.id.bphone2);
        this.bdial1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Checckstore2.this.showdial2();
            }
        });
        this.bloct1 = (ImageButton) findViewById(R.id.bloc3);
        this.bloct1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Checckstore2.this.showloct3();
            }
        });
        this.bdial1 = (ImageButton) findViewById(R.id.bphone3);
        this.bdial1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Checckstore2.this.showdial3();
            }
        });
    }

    /* access modifiers changed from: private */
    public void showloct1() {
        Intent intent = new Intent("android.intent.action.VIEW");
        intent.setData(Uri.parse("https://www.google.com/maps/dir//manure+shops+in+bangalore/@15.2375012,75.8860897,7z/data=!4m8!4m7!1m0!1m5!1m1!1s0x3bae17d1d7ea6b7f:0x7d585f066bda14!2m2!1d77.5761847!2d12.9914872"));
        startActivity(intent);
    }

    /* access modifiers changed from: private */
    public void showdial1() {
        startActivity(new Intent("android.intent.action.VIEW", Uri.parse("tel:09538021144")));
    }

    /* access modifiers changed from: private */
    public void showloct2() {
        Intent intent = new Intent("android.intent.action.VIEW");
        intent.setData(Uri.parse("https://www.google.com/maps/dir//the+garden+store+bangalore/@15.2541528,75.8884991,7z/data=!4m8!4m7!1m0!1m5!1m1!1s0x3bae17079d9e1855:0xe6ef5ead8ae85bb7!2m2!1d77.633024!2d13.014962"));
        startActivity(intent);
    }

    /* access modifiers changed from: private */
    public void showdial2() {
        startActivity(new Intent("android.intent.action.VIEW", Uri.parse("tel:08884501209")));
    }

    /* access modifiers changed from: private */
    public void showloct3() {
        Intent intent = new Intent("android.intent.action.VIEW");
        intent.setData(Uri.parse("https://www.google.com/maps/dir//nutrimax+organics/@15.2248622,75.8884983,7z/data=!4m8!4m7!1m0!1m5!1m1!1s0x3bae123b20bb5f53:0x11ef3533b278d7d0!2m2!1d77.71375!2d12.960558"));
        startActivity(intent);
    }

    /* access modifiers changed from: private */
    public void showdial3() {
        startActivity(new Intent("android.intent.action.VIEW", Uri.parse("tel:07337785333")));
    }
}
