package com.example.gogreen;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class Registration extends AppCompatActivity {
    private EditText email;
    /* access modifiers changed from: private */
    public FirebaseAuth firebaseAuth;
    private EditText password;
    /* access modifiers changed from: private */
    public ProgressDialog progressDialog;
    public Button reg;

    /* access modifiers changed from: protected */
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((int) R.layout.activity_registration);
        this.reg = (Button) findViewById(R.id.button3);
        this.email = (EditText) findViewById(R.id.ed4);
        this.password = (EditText) findViewById(R.id.pass);
        this.firebaseAuth = FirebaseAuth.getInstance();
        this.progressDialog = new ProgressDialog(this);
        this.reg.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Registration.this.registerUser();
            }
        });
    }

    public void registerUser() {
        String em = this.email.getText().toString().trim();
        String pw = this.password.getText().toString().trim();
        if (TextUtils.isEmpty(em)) {
            Toast.makeText(this, "Enter email id", 1).show();
        } else if (TextUtils.isEmpty(pw)) {
            Toast.makeText(this, "Enter password", 1).show();
        } else if (pw.length() < 6 || pw.length() > 10) {
            this.password.setError("password should be between 6 to 10 letters");
        } else {
            this.progressDialog.setMessage("Registering User");
            this.progressDialog.show();
            this.firebaseAuth.createUserWithEmailAndPassword(em, pw).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if (task.isSuccessful()) {
                        Registration.this.firebaseAuth.getCurrentUser().sendEmailVerification().addOnCompleteListener(new OnCompleteListener<Void>() {
                            public void onComplete(@NonNull Task<Void> task) {
                                if (task.isSuccessful()) {
                                    Toast.makeText(Registration.this, "Registration successful please check your email for verification", 1).show();
                                    Registration.this.startActivity(new Intent(Registration.this, Login.class));
                                    Registration.this.progressDialog.dismiss();
                                    return;
                                }
                                Toast.makeText(Registration.this, task.getException().getMessage(), 1).show();
                            }
                        });
                        return;
                    }
                    Toast.makeText(Registration.this, "couldn't Register", 1).show();
                    Registration.this.progressDialog.dismiss();
                }
            });
        }
    }
}
