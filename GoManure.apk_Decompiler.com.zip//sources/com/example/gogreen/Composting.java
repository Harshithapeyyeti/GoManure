package com.example.gogreen;

import android.os.Bundle;
import android.transition.AutoTransition;
import android.transition.TransitionManager;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.views.YouTubePlayerView;

public class Composting extends AppCompatActivity {
    TextView detailtt;
    TextView detailtt2;
    TextView detailtt3;
    TextView detailtt4;
    TextView detailtt5;
    LinearLayout layouta3;
    LinearLayout layoutb3;
    LinearLayout layoutc3;
    LinearLayout layoutd3;
    LinearLayout layoute3;

    /* access modifiers changed from: protected */
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((int) R.layout.activity_composting);
        getLifecycle().addObserver((YouTubePlayerView) findViewById(R.id.youtube_player_view));
        this.detailtt = (TextView) findViewById(R.id.det11);
        this.layouta3 = (LinearLayout) findViewById(R.id.lay22);
        this.layouta3.getLayoutTransition().enableTransitionType(4);
        this.detailtt2 = (TextView) findViewById(R.id.det22);
        this.layoutb3 = (LinearLayout) findViewById(R.id.lay44);
        this.layoutb3.getLayoutTransition().enableTransitionType(4);
        this.detailtt3 = (TextView) findViewById(R.id.det33);
        this.layoutc3 = (LinearLayout) findViewById(R.id.lay55);
        this.layoutc3.getLayoutTransition().enableTransitionType(4);
        this.detailtt4 = (TextView) findViewById(R.id.det34);
        this.layoutd3 = (LinearLayout) findViewById(R.id.lay66);
        this.layoutd3.getLayoutTransition().enableTransitionType(4);
    }

    public void exp11(View view) {
        int v = 8;
        if (this.detailtt.getVisibility() == 8) {
            v = 0;
        }
        TransitionManager.beginDelayedTransition(this.layouta3, new AutoTransition());
        this.detailtt.setVisibility(v);
    }

    public void exp22(View view) {
        int v = 8;
        if (this.detailtt2.getVisibility() == 8) {
            v = 0;
        }
        TransitionManager.beginDelayedTransition(this.layoutb3, new AutoTransition());
        this.detailtt2.setVisibility(v);
    }

    public void exp55(View view) {
        int v = 8;
        if (this.detailtt3.getVisibility() == 8) {
            v = 0;
        }
        TransitionManager.beginDelayedTransition(this.layoutc3, new AutoTransition());
        this.detailtt3.setVisibility(v);
    }

    public void exp66(View view) {
        int v = 8;
        if (this.detailtt4.getVisibility() == 8) {
            v = 0;
        }
        TransitionManager.beginDelayedTransition(this.layoutd3, new AutoTransition());
        this.detailtt4.setVisibility(v);
    }
}
