package com.example.gogreen;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class Menu extends AppCompatActivity {
    public Button check;
    public Button comph;
    public Button mantype;

    /* access modifiers changed from: protected */
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((int) R.layout.activity_menu);
        this.mantype = (Button) findViewById(R.id.mantypes);
        this.mantype.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Menu.this.startActivity(new Intent(Menu.this, Benefits.class));
            }
        });
        this.check = (Button) findViewById(R.id.button4);
        this.check.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Menu.this.startActivity(new Intent(Menu.this, Storemenu.class));
            }
        });
        this.comph = (Button) findViewById(R.id.hom);
        this.comph.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Menu.this.startActivity(new Intent(Menu.this, Homecomposting.class));
            }
        });
    }
}
