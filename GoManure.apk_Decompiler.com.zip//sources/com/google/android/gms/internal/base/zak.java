package com.google.android.gms.internal.base;

import android.graphics.Canvas;
import android.net.Uri;
import android.widget.ImageView;

/* compiled from: com.google.android.gms:play-services-base@@17.1.0 */
public final class zak extends ImageView {
    public static void zaa(Uri uri) {
        throw new NoSuchMethodError();
    }

    public static int zacf() {
        throw new NoSuchMethodError();
    }

    public static void zai(int i) {
        throw new NoSuchMethodError();
    }

    /* access modifiers changed from: protected */
    public final void onMeasure(int i, int i2) {
        throw new NoSuchMethodError();
    }

    /* access modifiers changed from: protected */
    public final void onDraw(Canvas canvas) {
        throw new NoSuchMethodError();
    }
}
