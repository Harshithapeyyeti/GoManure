package com.google.android.gms.internal.base;

import android.graphics.drawable.Drawable;
import androidx.collection.LruCache;

/* compiled from: com.google.android.gms:play-services-base@@17.1.0 */
public final class zaj extends LruCache<Object, Drawable> {
    public zaj() {
        super(10);
    }
}
