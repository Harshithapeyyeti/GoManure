package com.google.android.gms.internal.base;

/* compiled from: com.google.android.gms:play-services-base@@17.1.0 */
public final class zan {
    private static final zal zasd;
    private static volatile zal zase;

    public static zal zact() {
        return zase;
    }

    static {
        zap zap = new zap();
        zasd = zap;
        zase = zap;
    }
}
