package com.google.android.gms.internal.base;

import android.graphics.drawable.Drawable;

/* compiled from: com.google.android.gms:play-services-base@@17.1.0 */
final class zai extends Drawable.ConstantState {
    private zai() {
    }

    public final Drawable newDrawable() {
        return zaf.zany;
    }

    public final int getChangingConfigurations() {
        return 0;
    }
}
