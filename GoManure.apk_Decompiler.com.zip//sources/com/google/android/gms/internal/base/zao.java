package com.google.android.gms.internal.base;

/* compiled from: com.google.android.gms:play-services-base@@17.1.0 */
public final class zao {
    private static final int zasf = 1;
    public static final int zasg = 2;
    private static final /* synthetic */ int[] zash = {1, 2};
}
