package com.google.android.gms.internal.p001firebaseauthapi;

/* renamed from: com.google.android.gms.internal.firebase-auth-api.zzfs  reason: invalid package */
/* compiled from: com.google.firebase:firebase-auth@@21.0.1 */
final /* synthetic */ class zzfs {
    static final /* synthetic */ int[] zza = new int[7];

    static {
        zzzv.zza();
        try {
            zza[3] = 1;
        } catch (NoSuchFieldError e) {
        }
        try {
            zza[4] = 2;
        } catch (NoSuchFieldError e2) {
        }
        try {
            zza[2] = 3;
        } catch (NoSuchFieldError e3) {
        }
        try {
            zza[5] = 4;
        } catch (NoSuchFieldError e4) {
        }
        try {
            zza[6] = 5;
        } catch (NoSuchFieldError e5) {
        }
        try {
            zza[0] = 6;
        } catch (NoSuchFieldError e6) {
        }
        try {
            zza[1] = 7;
        } catch (NoSuchFieldError e7) {
        }
    }
}
